#!/usr/bin/env node

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..');

function listJsFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...listJsFiles(full));
    if (entry.isFile() && entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

function run(command, args, options = {}) {
  return spawnSync(command, args, {
    cwd: root,
    encoding: 'utf8',
    ...options
  });
}

for (const file of listJsFiles(path.join(root, 'src')).concat(path.join(root, 'bin', 'orca.js'))) {
  const result = run(process.execPath, ['--check', file]);
  assert.strictEqual(result.status, 0, `${file} failed syntax check:\n${result.stderr}`);
}

const help = run(process.execPath, ['bin/orca.js', '--help'], {
  env: { ...process.env, HOME: fs.mkdtempSync(path.join(os.tmpdir(), 'orca-cli-home-')) }
});
assert.strictEqual(help.status, 0, help.stderr || help.stdout);
assert.match(help.stdout, /Usage: orca/);
assert.match(help.stdout, /kickstart/);

const index = require(path.join(root, 'src'));
assert.strictEqual(typeof index.login, 'function');
assert.strictEqual(typeof index.utils.parsePort, 'function');
assert.strictEqual(index.utils.parsePort('65535'), 65535);
assert.throws(() => index.utils.parsePort('0'), /between 1 and 65535/);

console.log('orca-cli smoke tests passed');
