/**
 * Utility functions for orcapt CLI
 */

const { spawn } = require('cross-spawn');
const { execFile } = require('child_process');
const util = require('util');
const chalk = require('chalk');
const { parsePort } = require('./cli');

const execFilePromise = util.promisify(execFile);

/**
 * Check if a command exists in the system.
 * This checks PATH presence instead of relying on `<command> --version`.
 */
async function commandExists(command) {
  return new Promise((resolve) => {
    const lookupCommand = process.platform === 'win32' ? 'where' : 'which';
    const child = spawn(lookupCommand, [command], {
      stdio: 'ignore',
      shell: false
    });

    child.on('close', (code) => resolve(code === 0));
    child.on('error', () => resolve(false));
  });
}

/**
 * Get Python command (python3 or python)
 * @returns {Promise<string|null>}
 */
async function getPythonCommand() {
  if (await commandExists('python3')) return 'python3';
  if (await commandExists('python')) return 'python';
  return null;
}

/**
 * Get the virtual environment paths based on OS
 * @returns {Object}
 */
function getVenvPaths() {
  const isWindows = process.platform === 'win32';

  return {
    python: isWindows ? 'orca_env\\Scripts\\python.exe' : 'orca_env/bin/python',
    pip: isWindows ? 'orca_env\\Scripts\\pip.exe' : 'orca_env/bin/pip',
    activate: isWindows ? 'orca_env\\Scripts\\activate' : 'source orca_env/bin/activate'
  };
}

/**
 * Run a command and stream output
 * @param {string} command - Command to run
 * @param {Array} args - Command arguments
 * @param {Object} options - Spawn options
 * @returns {Promise<number>} Exit code
 */
function runCommand(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: false,
      ...options
    });

    child.on('close', (code) => {
      if (code === 0) resolve(code);
      else reject(new Error(`Command failed with exit code ${code}`));
    });

    child.on('error', reject);
  });
}

/**
 * Run a command silently and return output
 * @param {string} command - Command to run
 * @param {Array} args - Command arguments
 * @param {Object} options - Spawn options
 * @returns {Promise<string>} Output
 */
function runCommandSilent(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: 'pipe',
      shell: false,
      ...options
    });

    let output = '';
    let errorOutput = '';

    if (child.stdout) child.stdout.on('data', (data) => { output += data.toString(); });
    if (child.stderr) child.stderr.on('data', (data) => { errorOutput += data.toString(); });

    child.on('close', (code) => {
      if (code === 0) resolve(output);
      else reject(new Error(errorOutput || output));
    });

    child.on('error', reject);
  });
}

/**
 * Spawn a background process
 * @param {string} command - Command to run
 * @param {Array} args - Command arguments
 * @param {Object} options - Spawn options
 * @returns {ChildProcess}
 */
function spawnBackground(command, args = [], options = {}) {
  return spawn(command, args, {
    stdio: 'pipe',
    shell: false,
    detached: false,
    ...options
  });
}

/**
 * Wait for a port to be ready
 * @param {number|string} port - Port to check
 * @param {number} timeout - Timeout in ms
 * @returns {Promise<boolean>}
 */
async function waitForPort(port, timeout = 10000) {
  const net = require('net');
  const normalizedPort = parsePort(port);
  const startTime = Date.now();

  return new Promise((resolve) => {
    let settled = false;

    const finish = (value) => {
      if (!settled) {
        settled = true;
        resolve(value);
      }
    };

    const checkPort = () => {
      if (settled) return;
      if (Date.now() - startTime > timeout) {
        finish(false);
        return;
      }

      const socket = new net.Socket();
      socket.setTimeout(500);
      socket.once('connect', () => {
        socket.destroy();
        finish(true);
      });
      socket.once('timeout', () => {
        socket.destroy();
        setTimeout(checkPort, 500);
      });
      socket.once('error', () => {
        socket.destroy();
        setTimeout(checkPort, 500);
      });
      socket.connect(normalizedPort, '127.0.0.1');
    };

    checkPort();
  });
}

/**
 * Check if a port is in use
 * @param {number|string} port - Port to check
 * @returns {Promise<boolean>}
 */
async function isPortInUse(port) {
  const net = require('net');
  const normalizedPort = parsePort(port);

  return new Promise((resolve) => {
    const server = net.createServer();

    server.once('error', (err) => resolve(err.code === 'EADDRINUSE'));
    server.once('listening', () => {
      server.close(() => resolve(false));
    });
    server.listen(normalizedPort, '127.0.0.1');
  });
}

async function getPidsForPort(port) {
  const normalizedPort = parsePort(port);

  if (process.platform === 'win32') {
    const { stdout } = await execFilePromise('netstat', ['-ano']);
    return stdout
      .split(/\r?\n/)
      .filter((line) => line.includes(`:${normalizedPort}`))
      .map((line) => line.trim().split(/\s+/).pop())
      .filter((pid) => pid && pid !== '0');
  }

  try {
    const { stdout } = await execFilePromise('lsof', [`-ti:${normalizedPort}`]);
    return stdout.trim().split(/\s+/).filter(Boolean);
  } catch (error) {
    if (process.platform !== 'darwin') {
      try {
        const { stdout } = await execFilePromise('fuser', [`${normalizedPort}/tcp`]);
        return stdout.trim().split(/\s+/).filter(Boolean);
      } catch (_) {
        return [];
      }
    }
    return [];
  }
}

/**
 * Kill process using a specific port.
 * Port is validated before it reaches OS commands.
 * @param {number|string} port - Port number
 * @returns {Promise<boolean>} True if a process was killed
 */
async function killPort(port) {
  const pids = [...new Set(await getPidsForPort(port))];
  if (pids.length === 0) return false;

  for (const pid of pids) {
    try {
      if (process.platform === 'win32') {
        await execFilePromise('taskkill', ['/F', '/PID', pid]);
      } else {
        process.kill(Number(pid), 'SIGKILL');
      }
    } catch (_) {
      // Process might already be gone.
    }
  }

  return pids.length > 0;
}

/**
 * Ensure port is available. The safe default is to fail fast instead of killing
 * unrelated user processes. Pass { killExisting: true } for explicit cleanup.
 * @param {number|string} port - Port to check and optionally free
 * @param {string} portName - Name for logging (e.g., 'UI', 'Agent')
 * @param {Object} options - Options
 * @returns {Promise<void>}
 */
async function ensurePortAvailable(port, portName = 'Port', options = {}) {
  const normalizedPort = parsePort(port, `${portName} port`);

  if (!(await isPortInUse(normalizedPort))) return;

  if (!options.killExisting) {
    throw new Error(`${portName} port ${normalizedPort} is already in use. Choose another port or stop the existing process.`);
  }

  console.log(chalk.yellow(`⚠ ${portName} port ${normalizedPort} is in use; stopping the process because cleanup was explicitly requested...`));
  const killed = await killPort(normalizedPort);
  if (!killed) {
    throw new Error(`Could not free ${portName} port ${normalizedPort}`);
  }
  await new Promise((resolve) => setTimeout(resolve, 1000));
}

/**
 * Print formatted messages
 */
const print = {
  title: (text) => console.log(chalk.magenta.bold(`\n${'='.repeat(60)}\n${text}\n${'='.repeat(60)}\n`)),
  step: (text) => console.log(chalk.cyan(`► ${text}`)),
  success: (text) => console.log(chalk.green(`✓ ${text}`)),
  error: (text) => console.log(chalk.red(`✗ ${text}`)),
  warning: (text) => console.log(chalk.yellow(`⚠ ${text}`)),
  info: (text) => console.log(chalk.blue(`ℹ ${text}`)),
  url: (label, url) => console.log(chalk.cyan(`${label}:`), chalk.underline(url))
};

module.exports = {
  commandExists,
  getPythonCommand,
  getVenvPaths,
  runCommand,
  runCommandSilent,
  spawnBackground,
  waitForPort,
  isPortInUse,
  killPort,
  ensurePortAvailable,
  print
};
