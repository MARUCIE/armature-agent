/**
 * Shared CLI validation and presentation helpers.
 */

const SENSITIVE_KEY_PATTERN = /(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|client[_-]?secret|auth|credential)/i;

function parseInteger(value, options = {}) {
  const {
    name = 'value',
    min = Number.MIN_SAFE_INTEGER,
    max = Number.MAX_SAFE_INTEGER,
    defaultValue
  } = options;

  if (value === undefined || value === null || value === '') {
    if (defaultValue !== undefined) return defaultValue;
    throw new Error(`${name} is required`);
  }

  const parsed = Number(value);
  if (!Number.isInteger(parsed)) {
    throw new Error(`${name} must be an integer`);
  }
  if (parsed < min || parsed > max) {
    throw new Error(`${name} must be between ${min} and ${max}`);
  }
  return parsed;
}

function parsePort(value, name = 'port') {
  return parseInteger(value, { name, min: 1, max: 65535 });
}

function isSensitiveKey(key = '') {
  return SENSITIVE_KEY_PATTERN.test(String(key));
}

function maskSecret(value) {
  if (value === undefined || value === null || value === '') return '';
  const text = String(value);
  if (text.length <= 4) return '****';
  return `${text.slice(0, 2)}****${text.slice(-2)}`;
}

function displayEnvValue(key, value) {
  return isSensitiveKey(key) ? maskSecret(value) : value;
}

function parseKeyValue(input, fieldName = '--env') {
  const index = String(input).indexOf('=');
  if (index <= 0) {
    throw new Error(`${fieldName} must use KEY=value format`);
  }
  const key = String(input).slice(0, index).trim();
  const value = String(input).slice(index + 1);
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
    throw new Error(`${fieldName} key must be a valid environment variable name`);
  }
  return [key, value];
}

function replacePathParams(template, params = {}) {
  return Object.entries(params).reduce((endpoint, [key, value]) => {
    return endpoint.replace(new RegExp(`\\{${key}\\}`, 'g'), encodeURIComponent(String(value)));
  }, template);
}

function appendQuery(endpoint, query = {}) {
  const entries = Object.entries(query)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);

  if (entries.length === 0) return endpoint;
  return `${endpoint}${endpoint.includes('?') ? '&' : '?'}${entries.join('&')}`;
}

module.exports = {
  parseInteger,
  parsePort,
  isSensitiveKey,
  maskSecret,
  displayEnvValue,
  parseKeyValue,
  replacePathParams,
  appendQuery
};
