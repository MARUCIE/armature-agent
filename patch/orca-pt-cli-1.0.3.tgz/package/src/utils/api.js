/**
 * Shared HTTP helpers for Orca CLI API calls.
 */

const http = require('http');
const https = require('https');
const { API_BASE_URL } = require('../config');

const DEFAULT_TIMEOUT_MS = Number(process.env.ORCA_HTTP_TIMEOUT_MS || 30000);

function parseJsonResponse(data) {
  if (!data) return {};
  try {
    return JSON.parse(data);
  } catch (error) {
    const err = new Error(`Invalid JSON response: ${data.slice(0, 500)}`);
    err.raw = data;
    throw err;
  }
}

function buildAuthHeaders(credentials, style = 'tenantToken') {
  if (!credentials) return {};

  if (style === 'legacyWorkspaceToken') {
    return {
      'x-workspace': credentials.workspace,
      'x-token': credentials.token,
      'x-mode': credentials.mode || 'team'
    };
  }

  return {
    'X-Workspace': credentials.token,
    'X-Tenant': credentials.tenant || credentials.workspace
  };
}

function makeJsonRequest({
  method = 'GET',
  endpoint,
  body = null,
  credentials = null,
  authStyle = 'tenantToken',
  baseUrl = API_BASE_URL,
  headers = {},
  timeoutMs = DEFAULT_TIMEOUT_MS
}) {
  return new Promise((resolve, reject) => {
    const url = new URL(endpoint, baseUrl);
    const isHttps = url.protocol === 'https:';
    const httpModule = isHttps ? https : http;
    const bodyText = body === null || body === undefined ? null : JSON.stringify(body);

    const requestHeaders = {
      Accept: 'application/json',
      ...buildAuthHeaders(credentials, authStyle),
      ...headers
    };

    if (bodyText !== null) {
      requestHeaders['Content-Type'] = 'application/json';
      requestHeaders['Content-Length'] = Buffer.byteLength(bodyText);
    }

    const req = httpModule.request({
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: `${url.pathname}${url.search}`,
      method,
      headers: requestHeaders
    }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        try {
          const response = parseJsonResponse(data);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(response);
          } else {
            reject({ statusCode: res.statusCode, response });
          }
        } catch (error) {
          reject(error);
        }
      });
    });

    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`Request timed out after ${timeoutMs}ms`));
    });

    req.on('error', reject);
    if (bodyText !== null) req.write(bodyText);
    req.end();
  });
}

module.exports = {
  makeJsonRequest,
  buildAuthHeaders,
  parseJsonResponse,
  DEFAULT_TIMEOUT_MS
};
