/**
 * orcapt Database Commands
 * Manage PostgreSQL databases via orcapt Deploy API
 */

const chalk = require('chalk');
const ora = require('ora');
const { getCredentials } = require('./login');
const { API_BASE_URL, API_ENDPOINTS } = require('../config');
const { handleError } = require('../utils/errorHandler');
const { makeJsonRequest } = require('../utils/api');
const { maskSecret } = require('../utils/cli');

/**
 * Make API request to orcapt Deploy API
 */
function makeApiRequest(method, endpoint, credentials, body = null) {
  return makeJsonRequest({
    method,
    endpoint,
    credentials,
    body,
    authStyle: 'legacyWorkspaceToken'
  });
}

/**
 * DB Create Command - Create a new PostgreSQL database
 */
async function dbCreate(options) {
  console.log(chalk.cyan('\n============================================================'));
  console.log(chalk.cyan('🗄️  Creating PostgreSQL Database'));
  console.log(chalk.cyan('============================================================\n'));

  // Get credentials from login
  const credentials = getCredentials();
  if (!credentials) {
    console.log(chalk.red('✗ Not authenticated'));
    console.log(chalk.cyan('Please run:'), chalk.yellow('orca login'), chalk.cyan('first (fallback: orcapt login)\n'));
    process.exit(1);
  }

  console.log(chalk.white('Workspace:'), chalk.yellow(credentials.workspace));
  console.log(chalk.white('API:      '), chalk.yellow(API_BASE_URL));

  const spinner = ora('Creating database...').start();

  try {
    // Hybrid DB API endpoint: creates/uses workspace DB and creates a schema
    const response = await makeApiRequest('POST', API_ENDPOINTS.DB_CREATE, credentials);

    spinner.succeed(chalk.green('Database created successfully!'));

    console.log(chalk.cyan('\n============================================================'));
    console.log(chalk.green('✓ Database Ready'));
    console.log(chalk.cyan('============================================================'));
    // Show actual DB and schema
    console.log(chalk.white('Database:  '), chalk.yellow(response.database_name));
    console.log(chalk.white('Schema:    '), chalk.yellow(response.schema_name));
    console.log(chalk.white('Username:  '), chalk.yellow(response.username));
    console.log(chalk.white('Password:  '), chalk.yellow(maskSecret(response.password)));
    console.log(chalk.gray('           Full password is only available from the API response; avoid printing it in shared terminals.'));
    console.log(chalk.white('Workspace: '), chalk.yellow(response.workspace_name));
    
    console.log(chalk.cyan('\n📋 Connection String:'));
    // Use the connection string from the response if available
    const connString = response.connection_info?.connection_string || 
      `postgresql://${response.username}:${response.password}@localhost:6432/${response.database_name}?options=-csearch_path%3D${response.schema_name}`;
    console.log(chalk.yellow(`   ${connString.replace(response.password || '', maskSecret(response.password || ''))}`));
    
    console.log(chalk.cyan('\n💡 Pull the raw connection details from the API/UI when you are ready to store them in a secret manager.'));
    console.log(chalk.cyan('============================================================\n'));

  } catch (error) {
    spinner.fail(chalk.red('Failed to create database'));
    handleError(error, 'Database creation');
    process.exit(1);
  }
}

/**
 * DB List Command - List all databases for workspace
 */
async function dbList() {
  console.log(chalk.cyan('\n============================================================'));
  console.log(chalk.cyan('📋 Listing Databases'));
  console.log(chalk.cyan('============================================================\n'));

  // Get credentials from login
  const credentials = getCredentials();
  if (!credentials) {
    console.log(chalk.red('✗ Not authenticated'));
    console.log(chalk.cyan('Please run:'), chalk.yellow('orca login'), chalk.cyan('first (fallback: orcapt login)\n'));
    process.exit(1);
  }

  console.log(chalk.white('Workspace:'), chalk.yellow(credentials.workspace));

  const spinner = ora('Fetching databases...').start();

  try {
    // DB API endpoint (returns list of { database_name, schema_name })
    const response = await makeApiRequest('GET', API_ENDPOINTS.DB_LIST, credentials);

    spinner.succeed(chalk.green('Databases retrieved'));

    console.log(chalk.cyan('\n============================================================'));
    
    if (response.count === 0) {
      console.log(chalk.yellow('No databases found'));
      console.log(chalk.cyan('\nCreate one with:'), chalk.white('orca db create --postgres'));
    } else {
      console.log(chalk.green(`✓ Found ${response.count} database${response.count > 1 ? 's' : ''}`));
      console.log(chalk.cyan('============================================================\n'));
      
      // Show schemas as databases to avoid confusion
      const items = response.databases || response.schemas || [];
      items.forEach((item, index) => {
        const name = typeof item === 'string' ? item : (item.schema_name || item.database_name);
        console.log(chalk.white(`  ${index + 1}. ${name}`));
      });
    }
    
    console.log(chalk.cyan('============================================================\n'));

  } catch (error) {
    spinner.fail(chalk.red('Failed to list databases'));
    handleError(error, 'Database listing');
    process.exit(1);
  }
}

/**
 * DB Remove Command - Delete a database
 */
async function dbRemove(databaseName) {
  if (!databaseName) {
    console.log(chalk.red('\n✗ Database name is required'));
    console.log(chalk.cyan('Usage:'), chalk.white('orca db remove <database-name>\n'));
    process.exit(1);
  }

  console.log(chalk.cyan('\n============================================================'));
  console.log(chalk.cyan('🗑️  Removing Database'));
  console.log(chalk.cyan('============================================================\n'));

  // Get credentials from login
  const credentials = getCredentials();
  if (!credentials) {
    console.log(chalk.red('✗ Not authenticated'));
    console.log(chalk.cyan('Please run:'), chalk.yellow('orca login'), chalk.cyan('first (fallback: orcapt login)\n'));
    process.exit(1);
  }

  console.log(chalk.white('Database: '), chalk.yellow(databaseName));
  console.log(chalk.white('Workspace:'), chalk.yellow(credentials.workspace));

  const spinner = ora('Deleting database...').start();

  try {
    // Delete a single schema under the workspace database
    const response = await makeApiRequest('DELETE', `${API_ENDPOINTS.DB_DELETE}/${encodeURIComponent(databaseName)}`, credentials);

    spinner.succeed(chalk.green('Database deleted successfully!'));

    console.log(chalk.cyan('\n============================================================'));
    console.log(chalk.green('✓ Database Removed'));
    console.log(chalk.cyan('============================================================'));
    // Present schema as database name
    console.log(chalk.white('Database:  '), chalk.yellow(response.schema_name || databaseName));
    console.log(chalk.white('Workspace: '), chalk.yellow(response.workspace_name));
    console.log(chalk.cyan('============================================================\n'));

  } catch (error) {
    spinner.fail(chalk.red('Failed to delete database'));
    handleError(error, 'Database deletion');
    process.exit(1);
  }
}

module.exports = {
  dbCreate,
  dbList,
  dbRemove
};

