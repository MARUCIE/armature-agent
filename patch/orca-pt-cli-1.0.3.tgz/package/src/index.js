/**
 * Public module surface for programmatic consumers of @orca-pt/cli.
 */

const loginCommands = require('./commands/login');

module.exports = {
  ...loginCommands,
  utils: {
    ...require('./utils/cli'),
    ...require('./utils')
  },
  commands: {
    login: loginCommands
  },
  config: require('./config')
};
